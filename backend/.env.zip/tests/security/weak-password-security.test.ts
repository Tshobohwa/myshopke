import request from 'supertest';
import bcrypt from 'bcryptjs';
import jwt from 'js